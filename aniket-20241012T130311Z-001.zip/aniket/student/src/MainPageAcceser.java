public class MainPageAcceser {

    public static mainpage mainpage;

}